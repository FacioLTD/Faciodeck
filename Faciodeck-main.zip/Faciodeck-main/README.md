
  # One-Pager Investor Deck

  This is a code bundle for One-Pager Investor Deck. The original project is available at https://www.figma.com/design/PimTCUe9nGmy9b7mgNHeF4/One-Pager-Investor-Deck.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  